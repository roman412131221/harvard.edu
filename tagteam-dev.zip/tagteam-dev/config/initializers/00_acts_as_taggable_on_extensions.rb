# ActsAsTaggableOn::Tag.remove_unused = true
require File.dirname(__FILE__) + '/../../lib/acts_as_taggable_on_extensions/lib/acts_as_taggable_on_extensions.rb'
