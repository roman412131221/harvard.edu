NonStupidDigestAssets.whitelist += [/ckeditor\/.*/]
