# frozen_string_literal: true

FactoryBot.define do
  factory :feed_retrieval do
    feed
  end
end
