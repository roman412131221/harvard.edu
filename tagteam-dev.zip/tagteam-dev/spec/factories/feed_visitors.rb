# frozen_string_literal: true

FactoryBot.define do
  factory :feed_visitor
end
