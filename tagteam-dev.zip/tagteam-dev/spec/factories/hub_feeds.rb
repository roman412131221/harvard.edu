# frozen_string_literal: true

FactoryBot.define do
  factory :hub_feed do
    hub
    feed
  end
end
