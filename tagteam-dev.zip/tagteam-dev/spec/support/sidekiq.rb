# frozen_string_literal: true
require 'sidekiq/testing'
Sidekiq::Testing.inline!
