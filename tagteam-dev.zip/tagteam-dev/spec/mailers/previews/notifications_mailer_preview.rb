# frozen_string_literal: true

class NotificationsMailerPreview < ActionMailer::Preview
end
