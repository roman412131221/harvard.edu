# frozen_string_literal: true
require 'rails_helper'

RSpec.describe FeedRetrieval, type: :model do
end
