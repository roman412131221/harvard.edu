# frozen_string_literal: true
# Uninstall hook code here
