class FeedVisitor < ApplicationRecord
end
