# frozen_string_literal: true
class RepublishedFeedsController < ApplicationController
  before_action :authenticate_user!, except: [:index, :show, :items, :inputs, :removals]
  before_action :load_republished_feed, except: [:new, :create, :index]
  before_action :load_hub, only: [:new, :create, :index]
  before_action :register_breadcrumb

  after_action :verify_authorized, except: :index

  # Beef up cache rules.
  caches_action :index, :show, :items, :inputs, :removals, unless: proc { |_c| current_user }, expires_in: Tagteam::Application.config.default_action_cache_time, cache_path: proc {
    Digest::MD5.hexdigest(request.fullpath + '&per_page=' + get_per_page)
  }

  protect_from_forgery except: :items

  # A list of RepublishedFeeds (aka "remixed feeds") in a hub. Returns html, json, and xml.
  def index
    @republished_feeds = @hub.republished_feeds.paginate(page: params[:page], per_page: get_per_page)
    respond_to do |format|
      format.html { render layout: request.xhr? ? false : 'tabs' }
      format.json { render_for_api :default, json: @republished_feeds }
      format.xml { render_for_api :default, xml: @republished_feeds }
    end
  end

  # An individual RepublishedFeed. Returns html, json, and xml.
  def show
    @show_auto_discovery_params = remix_items_url(@republished_feed.url_key, format: :rss)
    respond_to do |format|
      format.html { render layout: request.xhr? ? false : 'tabs' }
      format.json { render_for_api :default, json: @republished_feed }
      format.xml { render_for_api :default, xml: @republished_feed }
    end
  end

  # A paginated list of FeedItems in this RepublishedFeed. Returns html, rss, atom, json, and xml.
  def items
    Feeds::StoreFeedVisitorJob.perform_later(
      request.path,
      request.format.symbol.to_s,
      request.remote_ip,
      request.user_agent
    )

    @show_auto_discovery_params = items_hub_republished_feed_url(@hub, @republished_feed, format: :rss)
    @search = @republished_feed.item_search
    unless @search.blank?
      @search.build do
        paginate page: params[:page], per_page: get_per_page
      end
      @search.execute!
    end
    respond_to do |format|
      format.html do
        template = params[:view] == 'grid' ? 'items_grid' : 'items'
        render template, layout: request.xhr? ? false : 'tabs'
      end
      format.rss {}
      format.atom {}
      format.json { render_for_api :default, json: @search.blank? ? [] : @search.results }
      format.xml { render_for_api :default, xml: @search.blank? ? [] : @search.results }
    end
  end

  # List the InputSource objects that add items to this RepublishedFeed.
  def inputs
    render layout: request.xhr? ? false : 'tabs'
  end

  # List the InputSource objects that remove items from this RepublishedFeed.
  def removals
    render layout: request.xhr? ? false : 'tabs'
  end

  def new
    @republished_feed = RepublishedFeed.new(hub_id: @hub.id)
    authorize @republished_feed
  end

  def create
    @republished_feed = RepublishedFeed.create_with_user(current_user, @hub, params)

    if @republished_feed.errors.present?
      skip_authorization
    else
      authorize @republished_feed
    end

    respond_to do |format|
      if @republished_feed.errors.present?
        # new instance needed to avoid breaking form
        flash[:error] = 'Could not add that remix.'
        format.html { render action: :new }
      else
        flash[:notice] = 'Created a new remix. You should switch to the "inputs" tab and add items for publishing.'
        format.html { redirect_to action: :show, id: @republished_feed.id }
      end
    end
  end

  def update
    @republished_feed.attributes = params[:republished_feed]
    respond_to do |format|
      if @republished_feed.save
        current_user.has_role!(:editor, @republished_feed)
        flash[:notice] = 'Edited that remix.'
        format.html { redirect_to action: :show, id: @republished_feed.id }
      else
        flash[:error] = 'Could not edit that remix.'
        format.html { render action: :update }
      end
    end
  end

  def edit; end

  def destroy
    @republished_feed.destroy
    flash[:notice] = 'Removed that remix.'
    redirect_to(hub_path(@hub))
  rescue
    flash[:error] = "Couldn't remove that remix."
    redirect_to(hub_path(@hub))
  end

  private

  def load_hub
    hub_id = params[:republished_feed].blank? ? params[:hub_id] : params[:republished_feed][:hub_id]
    @hub = Hub.find(hub_id)
  end

  def load_republished_feed
    @republished_feed = if params[:url_key].blank?
                          RepublishedFeed.find(params[:id])
                        else
                          RepublishedFeed.find_by!(url_key: params[:url_key])
                        end
    authorize @republished_feed

    @hub = @republished_feed.hub
  end

  def register_breadcrumb
    breadcrumbs.add @hub.title, hub_path(@hub)
  end
end
